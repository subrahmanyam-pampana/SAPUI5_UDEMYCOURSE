var queryString = window.location.search;
var urlParams = new URLSearchParams(queryString);
var SITE = urlParams.get('SITE');

var AppData = {
    dataSources: {
        miiQueries: {
            getTableDataQry: {
                url: "/XMII/Illuminator?QueryTemplate=ASML_Reports/MasterData/NC_Code_Definition_US55&OutputParameter=*&Content-Type=text/xml",
                parameters:{ "Param.1":SITE }
            }
        }
    },
    columsData: [
        { colCode: "NC_CODE", text: "NC Code" },
        { colCode: "DESCRIPTION", text: "Description" },
        { colCode: "STATUS", text: "Status" },
        { colCode: "ASIGN_NC_TO_COMPONENT", text: "Assign NC to Component" },
        { colCode: "NC_CATEGORY", text: "NC Category" },
        { colCode: "NC_DATA_TYPE", text: "NC Data Type" },
        { colCode: "COLLECT_REQ_DATA", text: "Collect Request Data" },
        { colCode: "MESSAGE_TYPE", text: "Message Type" },
        { colCode: "PRIORITY", text: "Priority" },
        { colCode: "MAX_NC_LIMIT", text: "Max NC Limit" },
        { colCode: "SEVERITY_THRESHOLD", text: "Severity Threshold" },
        { colCode: "SECONDARY_CODE_SPEC_INSTR", text: "Secoundary Code Special Instruction" },
        { colCode: "CLOSURE_REQ", text: "Closure required " },
        { colCode: "AUTO_CLOSE_PRIMARY_NC", text: "Auto Close Primary NC" },
        { colCode: "AUTO_CLOSE_INCIDENT", text: "Auto Close Incident" },
        { colCode: "SEC_REQ_FOR_CLOSURE", text: "Secoundary required for Closure" },
        { colCode: "ERP_QN_CODE", text: "ERP QN Code" },
        { colCode: "ERP_CATALOG", text: "ERP Catalog" },
        { colCode: "ERP_CODE_GROUP", text: "ERP Code Group" },
        { colCode: "ERP_CODE", text: "ERP Code" },
        { colCode: "CAN_BE_PRIMARY_CODE", text: "Can be Primary Code" },
        {
            colCode: "VALID_AT_OPER",
            text: "Valid at Operation",
            link: window.location.origin + "/XMII/CM/ASML_Reports/MasterData/NCValidAtOperations.html",
            parameters:["NC_CODE","VALID_AT_OPER"]
        },

        { colCode: "DISPOSITION_GROUP", text: "Disposition Group" },
        { colCode: "ENABLED", text: "Enabled" },
        { colCode: "ASSIGNED_NC_GROUP", text: "Assigned NC Group" },
        {
            colCode: "ASSIGNED_SECONDARIES",
            text: "Assigned Secoundaries",
            link: window.location.origin + "/XMII/CM/ASML_Reports/MasterData/SecondaryNCCodesForNC.html",
            parameters: ["NC_CODE"]
        },
        { colCode: "NOT_OBJ_CTRL", text: "Control Object  1" },
        { colCode: "NOT_OBJ_CTRL_2", text: "Control Object 2" }
    ],
    i18n: { AppTitle: "NC Code Definition Report" },

    xlsxData: {
        fileName: "NCCodeDefinitionReport.xlsx",
        ws_name: "NCCodeDefinitionReport"
    }

};

function createView() {
    var mainPage = new sap.m.Page({
        id: "mainPage",
        title: AppData.i18n.AppTitle,
        titleLevel: sap.ui.core.TitleLevel.H1,
        design: "Bold",
    });

    ///////////////////////////////////////////////////// Create Table ////////////////////////////////////////////////////////////////////////////////////////

    var oModel = new sap.ui.model.xml.XMLModel();
    oModel.attachRequestSent(function () {
        sap.ui.core.BusyIndicator.show();
    });
    oModel.attachRequestCompleted(function () {
        sap.ui.core.BusyIndicator.hide();
    });

    oModel.loadData(AppData.dataSources.miiQueries.getTableDataQry.url, AppData.dataSources.miiQueries.getTableDataQry.parameters, true, "", true);

    var mainTable = new sap.ui.table.Table({
        id: "mainTable",
    });
    var toolBar = new sap.m.OverflowToolbar();
    toolBar.addContent(new sap.m.ToolbarSpacer());
    toolBar.addContent(
        new sap.m.Button({
            icon: "sap-icon://excel-attachment",
            press: exportTable,
        })
    );
    mainTable.setToolbar(toolBar);

    AppData.columsData.forEach((item) => {
        item.width = "8rem";
    })

    AppData.columsData.forEach((item, index) => {

        var _template;
        if (item.link) {
            console.log(item.text + " has link: " + item.link);

            var _getLink = function (oEvent) {
                let _url = item.link + "?";
                var orowData =oEvent.getSource().getBindingContext().getObject();
                console.log(orowData);

               item.parameters.forEach(param => {
                 let propVal = orowData.getElementsByTagName(param)[0].textContent;
                    _url += param+ "=" + propVal + "&";
                    
                });
               _url+="SITE="+SITE;
                console.log( _url);
                window.open(_url,"_blank");
            };

            _template = new sap.m.Link({ press: function(oEvent){ _getLink(oEvent) } }).bindProperty("text", item.colCode);
        } else {
            _template = new sap.ui.commons.TextView().bindProperty(
                "text",
                item.colCode
            )
        }

        mainTable.addColumn(
              new sap.ui.table.Column({
                label: new sap.m.Label({
                    text: item.text,
                    design: "Bold",
                    wrapping: true,
                }),
             tooltip: new sap.ui.commons.RichTooltip({
                   text: item.text
               }),

                template: _template,
                hAlign: "Center",
                width: item.width,
                sortProperty: item.colCode,
                filterProperty: item.colCode
            }))
        });


    mainTable.bindRows("/Rowset/Row/");
    mainTable.setModel(oModel);
    console.log(mainTable.getModel());
    mainPage.addContent(mainTable);
    return mainPage;
}

//////////////////////EXCEL EXPORT///////////////////////////
function exportTable() {
    var dataArray = xmlToJson(
        $.parseXML(sap.ui.getCore().getElementById("mainTable").getModel().getXML())
    ).Rowsets.Rowset.Row;

  if(!Array.isArray(dataArray)){
        dataArray = [dataArray]
    }
    var filename = AppData.xlsxData.fileName;
    var ws_name = AppData.xlsxData.ws_name;


    var dataWS = XLSX.utils.json_to_sheet(dataArray);
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, dataWS, ws_name);
    // sheetAName is name of Worksheet

    XLSX.writeFile(wb, filename);
}

function xmlToJson(xml) {

    var headerMapping = {};
    AppData.columsData.forEach((item) => {
        headerMapping[item.colCode] = item.text;
    })

    // Create the return object
    var obj = {};

    if (xml.nodeType == 1) {
        // element
        // do attributes
        if (xml.attributes.length > 0) {
            obj["@attributes"] = {};
            for (var j = 0; j < xml.attributes.length; j++) {
                var attribute = xml.attributes.item(j);
                obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
            }
        }
    }

    // do children
    // If all text nodes inside, get concatenated text from them.
    var textNodes = [].slice.call(xml.childNodes).filter(function (node) {
        return node.nodeType === 3;
    });
    if (xml.hasChildNodes() && xml.childNodes.length === textNodes.length) {
        obj = [].slice.call(xml.childNodes).reduce(function (text, node) {
            return text + node.nodeValue;
        }, "");
    } else if (xml.hasChildNodes()) {
        for (var i = 0; i < xml.childNodes.length; i++) {
            var item = xml.childNodes.item(i);
            var nodeName = item.nodeName;
            if (headerMapping.hasOwnProperty(nodeName)) {
                nodeName = headerMapping[nodeName];
            }
            if (typeof obj[nodeName] == "undefined") {
                var new1 = xmlToJson(item);
                if (typeof new1 == "object" && new1.hasOwnProperty("#text")) {
                    delete new1["#text"];
                }
                obj[nodeName] = new1;
            } else {
                if (typeof obj[nodeName].push == "undefined") {
                    var old = obj[nodeName];
                    obj[nodeName] = [];
                    obj[nodeName].push(old);
                }
                var new2 = xmlToJson(item);
                if (typeof new2 == "object" && new2.hasOwnProperty("#text")) {
                    delete new2["#text"];
                }
                obj[nodeName].push(new2);
            }
        }
    }
    obj = obj === "---" ? "" : obj;
    return obj;
}
