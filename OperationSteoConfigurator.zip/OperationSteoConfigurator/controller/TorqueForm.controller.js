sap.ui.define([
	'sap/ui/core/mvc/Controller',
	'sap/m/MessageBox',
	'sap/ui/core/util/MockServer',
	'sap/ui/model/json/JSONModel',
	'sap/ui/model/odata/v2/ODataModel',
	"sap/ui/model/xml/XMLModel"
], function (Controller, MessageBox, MockServer,XMLModel, JSONModel, ODataModel) {
	"use strict";

	return Controller.extend("Att.controller.TorqueForm", {

		onInit: function () {

			var oStepList = new XMLModel("../model/stepData2.xml");
            sap.ui.getCore().setModel(oStepList);

			var oViewModel = new JSONModel();
			oViewModel.setProperty("/visible", true);
			this.getView().setModel(oViewModel, "test");

			this.getView().byId("smartformImportance").bindElement("/Rowset/Row");
		},
		fnFormatter: function (bVis) {
			return bVis;
		},
		onSelectionChange: function(oEvent) {
			var sImportance = oEvent.getParameter("item").getText();
			this.getView().byId("smartformImportance").setImportance(sImportance);
		}
	});
});