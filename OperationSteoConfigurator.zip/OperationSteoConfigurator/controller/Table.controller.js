sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/xml/XMLModel"
], function (Controller, JSONModel,XMLModel) {
    "use strict";
    return Controller.extend("Att.controller.Table", {

        onInit: function () {


            sap.ui.getCore().setModel(new JSONModel(oStepData), "stepList");

            // var oData = {
            //     "steps":[
            //       {stepType:"Torque",Torque:10,Angle:20},
            //       {stepType:"Place",Torque:10,Angle:20},
            //       {stepType:"Apply",Torque:10,Angle:20},
            //     ]
            // };

        //     var oXmlData = `<companies>
        //     <company name="Treefish Inc">
              
        //          <employees>3</employees>
            
        //       <contact phone="873">Barbara</contact>
        //     </company>
        //   </companies>`;

        

        //   var ConvtxmlTojson = function xmlToJson(xml) {

        //     var headerMapping = {};
        //     AppData.columsData.forEach((item) => {
        //         headerMapping[item.colCode] = item.text;
        //     })
        
        //     // Create the return object
        //     var obj = {};
        
        //     if (xml.nodeType == 1) {
        //         // element
        //         // do attributes
        //         if (xml.attributes.length > 0) {
        //             obj["@attributes"] = {};
        //             for (var j = 0; j < xml.attributes.length; j++) {
        //                 var attribute = xml.attributes.item(j);
        //                 obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
        //             }
        //         }
        //     }
        
        //     // do children
        //     // If all text nodes inside, get concatenated text from them.
        //     var textNodes = [].slice.call(xml.childNodes).filter(function (node) {
        //         return node.nodeType === 3;
        //     });
        //     if (xml.hasChildNodes() && xml.childNodes.length === textNodes.length) {
        //         obj = [].slice.call(xml.childNodes).reduce(function (text, node) {
        //             return text + node.nodeValue;
        //         }, "");
        //     } else if (xml.hasChildNodes()) {
        //         for (var i = 0; i < xml.childNodes.length; i++) {
        //             var item = xml.childNodes.item(i);
        //             var nodeName = item.nodeName;
        //             if (headerMapping.hasOwnProperty(nodeName)) {
        //                 nodeName = headerMapping[nodeName];
        //             }
        //             if (typeof obj[nodeName] == "undefined") {
        //                 var new1 = xmlToJson(item);
        //                 if (typeof new1 == "object" && new1.hasOwnProperty("#text")) {
        //                     delete new1["#text"];
        //                 }
        //                 obj[nodeName] = new1;
        //             } else {
        //                 if (typeof obj[nodeName].push == "undefined") {
        //                     var old = obj[nodeName];
        //                     obj[nodeName] = [];
        //                     obj[nodeName].push(old);
        //                 }
        //                 var new2 = xmlToJson(item);
        //                 if (typeof new2 == "object" && new2.hasOwnProperty("#text")) {
        //                     delete new2["#text"];
        //                 }
        //                 obj[nodeName].push(new2);
        //             }
        //         }
        //     }
        //     obj = obj === "---" ? "" : obj;
        //     return obj;
        // }


       // oXmlData = ConvtxmlTojson(oXmlData);
            var oStepList = new XMLModel("../model/stepData2.xml");

            sap.ui.getCore().setModel(oStepList);
            console.log(oStepList);



          
           
        }

    })

})