sap.ui.define([
		'sap/ui/core/Fragment',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel',
		"sap/ui/model/xml/XMLModel",
		"sap/m/MessageToast"
	], function(Fragment,Controller,JSONModel,XMLModel,MessageToast) {
	"use strict";

	var PageController = Controller.extend("Att.controller.Page", {

		onInit: function (oEvent) {

			// set explored app's demo model on this sample
			// var oModel = new JSONModel(sap.ui.require.toUrl("Att/mockdata/supplier.json"));

			var oModel = new XMLModel("../model/stepData3.xml");
			oModel.attachRequestCompleted(function() {
				this.byId('edit').setEnabled(true);
			}.bind(this));

			this.getView().setModel(oModel);
			//sap.ui.getCore().setModel(oModel);

			this._BindPath="/Rowset/Row/0";

			this.getView().bindElement(this._BindPath);

			this._formFragments = {};

			// Set the initial form to be the display one
			this._showFormFragment("Display");

			// to navigate to the page on phone and not show the split screen items
			var oSplitContainer = this.byId("SimpleFormSplitscreen");

			oSplitContainer.toDetail(this.createId("page"));
          

		},
		onAfterRendering:function(){

			console.log(this.byId("myFlexBox")); 
			console.log(this.byId("SimpleFormSplitscreen")); 
		},

		handleEditPress : function () {

			//Clone the data
			// this._oSupplier = Object.assign({}, this.getView().getModel().getData().SupplierCollection[0]);
			// this._oSupplier = Object.assign({}, this.getView().getModel().getData().getElementsByTagName("Row")[0]);
			this._oSupplier = this.getView().getModel().getData().getElementsByTagName("Row")[0];
			// console.log(this.getView().getModel().getData())
		   //  console.log(this._oSupplier)
			// var data = this.getView().getModel().getData();
			//debugger;
			this._toggleButtonsAndView(true);

		},

		// handleCancelPress : function () {

		// 	//Restore the data
		// 	var oModel = this.getView().getModel();
		// 	var oData = oModel.getData();

		// 	 console.log(this._oSupplier);
		// 	 debugger;
		// 	oData.getElementsByTagName("Row")[0].innerHTML = this._oSupplier;

		// 	oModel.setData(oData);
		// 	this._toggleButtonsAndView(false);

		// },

		handleSavePress : function () {

			this._toggleButtonsAndView(false);

		},

		_toggleButtonsAndView : function (bEdit) {
			var oView = this.getView();

			// Show the appropriate action buttons
			oView.byId("edit").setVisible(!bEdit);
			oView.byId("save").setVisible(bEdit);
			//oView.byId("cancel").setVisible(bEdit);

			// Set the right form type
			this._showFormFragment(bEdit ? "Change" : "Display");
		},

		_getFormFragment: function (sFragmentName) {
			var pFormFragment = this._formFragments[sFragmentName],
				oView = this.getView();

			if (!pFormFragment) {
				pFormFragment = Fragment.load({
					id: oView.getId(),
					name: "Att.view." + sFragmentName
				});
				this._formFragments[sFragmentName] = pFormFragment;
			}

			return pFormFragment;
		},

		_showFormFragment : function (sFragmentName) {
			var oPage = this.byId("page");

			oPage.removeAllContent();
			this._getFormFragment(sFragmentName).then(function(oVBox){
				oPage.insertContent(oVBox);
			});
		},
		showStepDetails:function(oEvent){
			
			MessageToast.show("Item pressed");
		    var sBindPath =	oEvent.getParameters().listItem.getBindingContextPath();
			this._BindPath = sBindPath

			this.getView().bindElement(this._BindPath);
			//debugger;
		},
		insertNewStep:function(){
			MessageToast.show("Insert New step");
		},
		canvasCalled:function(){
			MessageToast.show("canvas Called");
		}

	});

	return PageController;

});