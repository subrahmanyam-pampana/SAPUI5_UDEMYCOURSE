sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel",
    "sap/ui/model/xml/XMLModel"
], function (Controller, JSONModel, ResourceModel, XMLModel) {
    "use strict";
    return Controller.extend("Att.controller.Home", {

        onInit: function () {
            //  var i18nModel = new ResourceModel({
            //     bundleName:"Att.i18n.i18n"
            //  });

           

        },
        ShowStepList: function (oEvent) {
            var oButton = oEvent.getSource();
            this.byId("actionSheet").openBy(oButton);
        }


    })

})