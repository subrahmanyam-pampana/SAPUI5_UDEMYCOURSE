sap.ui.controller("myApp.controller.ratedProducts", {
  onInit: function () {},

  // onBeforeRendering: function(){},

  // onAfterRendering: function(){},

  // onExit:  function(){},

  // myCustomFunction: function(oEvent){}
});
