sap.ui.controller("myApp.controller.productDetails", {
  onInit: function () {},
});
